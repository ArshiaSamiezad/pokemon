package view;

import com.ahmz.test.tester.Scanner;

public class ExitMenu extends AppMenu{

    @Override
    public void check(Scanner scanner) {

    }
}
