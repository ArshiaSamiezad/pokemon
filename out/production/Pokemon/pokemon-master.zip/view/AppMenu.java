package view;

import com.ahmz.test.tester.Scanner;

public abstract class AppMenu {
    public abstract void check(Scanner scanner);
}
