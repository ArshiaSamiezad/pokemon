package enums;

public enum PokemonConditions {
    Sleeping("sleeping");

    public final String conidition;

    PokemonConditions(String conidition) {
        this.conidition = conidition;
    }
}
