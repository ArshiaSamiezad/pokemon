package model;

import model.Cards.*;

import java.util.ArrayList;

public class Player extends User{

    public Player(String username, String password, String email) {
        super(username, password, email);
    }
}
