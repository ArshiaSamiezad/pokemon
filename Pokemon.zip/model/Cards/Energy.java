package model.Cards;

public class Energy extends Card{
    public Energy(int buyValue, int sellValue, String name) {
        super(buyValue, sellValue, name, "energy");
    }
}
