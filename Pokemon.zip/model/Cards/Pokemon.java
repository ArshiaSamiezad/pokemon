package model.Cards;

public class Pokemon extends Card{
    public Pokemon(int buyValue, int sellValue, String name, String type) {
        super(buyValue, sellValue, name, type);
    }

}
