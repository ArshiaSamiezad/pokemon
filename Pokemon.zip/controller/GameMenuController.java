package controller;

public class GameMenuController {
}
