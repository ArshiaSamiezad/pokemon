package view;

import controller.GameMenuController;

import java.util.Scanner;

public class GameMenu extends AppMenu{
    private final GameMenuController controller = new GameMenuController();

    @Override
    public void check(Scanner scanner) {

    }
}
